# FPN

> Feature Pyramid Networks for Object Detection



针对cocoAP提升了2.3 个点

针对pascalAP提升了了3.8个点

![image-20241023095540201](assets/image-20241023095540201.png)